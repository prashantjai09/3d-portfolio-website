import React, { useState, useEffect, useRef } from "react";
import { AnimatePresence, motion } from "motion/react";
import { ThreeBackground } from "./components/ThreeBackground";
import { Navbar } from "./components/Navbar";
import { Hero } from "./components/Hero";
import { AboutSection } from "./components/AboutSection";
import { SkillsSection } from "./components/SkillsSection";
import { ProjectsSection } from "./components/ProjectsSection";
import { EducationSection } from "./components/EducationSection";
import { ResumeSection } from "./components/ResumeSection";
import { ContactSection } from "./components/ContactSection";
import { Footer } from "./components/Footer";

export default function App() {
  const [activeSection, setActiveSection] = useState("home");

  // Track window scroll coordinates to update active state triggers in Navbar
  useEffect(() => {
    const handleScroll = () => {
      const sections = ["home", "about", "skills", "projects", "education", "resume", "contact"];
      const scrollPosition = window.scrollY + window.innerHeight / 3;

      for (const sectionId of sections) {
        const el = document.getElementById(sectionId);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(sectionId);
            break;
          }
        }
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleNavigate = (sectionId: string) => {
    const targetEl = document.getElementById(sectionId);
    if (targetEl) {
      targetEl.scrollIntoView({ behavior: "smooth", block: "start" });
      setActiveSection(sectionId);
    }
  };

  return (
    <div id="app-root" className="min-h-screen relative text-zinc-150 bg-[#0B1020] overflow-x-hidden font-sans selection:bg-blue-600 selection:text-white">
      
      {/* 3D INTERACTIVE SYSTEM BACKDROP CANVAS (Three.js) */}
      <ThreeBackground />

      {/* FIXED BLUEPRINT GRID OVERLAYS AND LIGHTING */}
      <div className="fixed inset-0 blueprint-grid opacity-10 z-5 pointer-events-none" />
      <div className="fixed inset-0 blueprint-grid-fine opacity-10 z-5 pointer-events-none" />

      {/* DYNAMIC AMBIENT LIGHTING OVERLAYS */}
      <div className="fixed top-0 left-0 w-full h-[50vh] bg-gradient-to-b from-blue-900/10 to-transparent pointer-events-none z-1" />
      <div className="fixed bottom-0 right-0 w-[80vw] h-[80vh] bg-gradient-to-tl from-purple-900/10 to-transparent pointer-events-none z-1 rounded-full blur-[150px]" />
      <div className="fixed top-[20%] left-[10%] w-[50vw] h-[50vh] bg-blue-600/5 pointer-events-none z-1 rounded-full blur-[120px]" />
      
      {/* TRANSBRUSH GRADIENT MATTES */}
      <div className="fixed inset-0 bg-gradient-to-tr from-[#0B1020]/90 via-transparent to-cyan-900/5 z-1 pointer-events-none" />

      {/* STICKY GLASS NAVIGATION BAR */}
      <Navbar activeSection={activeSection} onNavigate={handleNavigate} />

      {/* CORE TIMELINE FLOW GRID SECTIONS */}
      <main className="relative z-10">
        
        {/* HERO ZONE */}
        <section id="home" className="min-h-screen flex flex-col justify-between">
          <Hero onScrollToSection={handleNavigate} />
        </section>

        {/* ABOUT PROFILE & TIMELINE */}
        <section id="about" className="relative border-t border-zinc-900/60 bg-gradient-to-b from-transparent to-neutral-950/30">
          <AboutSection />
        </section>

        {/* SKILLS MULTI-MATRIX WIDGETS */}
        <section id="skills" className="relative border-t border-zinc-900/40 bg-zinc-950/10">
          <SkillsSection />
        </section>

        {/* PROJECTS FEATURED 3D DECK */}
        <section id="projects" className="relative border-t border-zinc-900/50 bg-gradient-to-b from-transparent to-zinc-950/20">
          <ProjectsSection />
        </section>

        {/* EDUCATION & EXPERIENCE CHANNELS */}
        <section id="education" className="relative border-t border-zinc-900/40 bg-neutral-950/10">
          <EducationSection />
        </section>

        {/* INTERACTIVE RESUME & DOWNLOAD STATS */}
        <section id="resume" className="relative border-t border-zinc-900/40 bg-zinc-950/10">
          <ResumeSection />
        </section>

        {/* CONTACT CORRIDOR */}
        <section id="contact" className="relative border-t border-zinc-900/50 bg-gradient-to-b from-transparent to-zinc-950/40 pb-16">
          <ContactSection />
        </section>

      </main>

      {/* PERSISTENT MINIMAL FOOTER */}
      <Footer />

    </div>
  );
}
