import { SkillItem, ProjectItem, ExperienceItem, TimelineItem } from "./types";

export const SKILLS_DATA: SkillItem[] = [
  { name: "Python", category: "language", level: 94, icon: "FileCode2", color: "from-blue-500 to-yellow-500" },
  { name: "JavaScript / TS", category: "language", level: 92, icon: "Terminal", color: "from-blue-500 to-indigo-500" },
  { name: "SQL (PostgreSQL)", category: "backend", level: 88, icon: "Database", color: "from-blue-650 to-indigo-700" },
  { name: "Artificial Intelligence", category: "ai-ds", level: 88, icon: "Sparkles", color: "from-purple-500 to-pink-500" },
  { name: "Machine Learning", category: "ai-ds", level: 85, icon: "BrainCircuit", color: "from-indigo-500 to-purple-600" },
  { name: "Data Analysis", category: "ai-ds", level: 90, icon: "BarChart3", color: "from-violet-500 to-fuchsia-500" },
  { name: "Excel", category: "tool", level: 92, icon: "FileSpreadsheet", color: "from-emerald-500 to-green-600" },
  { name: "Power BI", category: "tool", level: 85, icon: "PieChart", color: "from-amber-400 to-orange-500" },
  { name: "Git", category: "tool", level: 90, icon: "GitBranch", color: "from-orange-500 to-red-600" }
];

export const PROJECTS_DATA: ProjectItem[] = [
  {
    id: "proj-1",
    title: "AI Resume Analyzer",
    subtitle: "Natural Language Processing Tool",
    description: "An AI-powered tool that analyzes resumes and provides suggestions for improvement using natural language processing.",
    techStack: ["Python", "Machine Learning", "Streamlit"],
    githubUrl: "https://github.com/prashantjaiswal/ai-resume-analyzer",
    liveUrl: "#",
    featured: true
  },
  {
    id: "proj-2",
    title: "Student Performance Dashboard",
    subtitle: "Interactive Analytics Dashboard",
    description: "An interactive dashboard for analyzing student performance using charts and visualizations.",
    techStack: ["Python", "Power BI", "Pandas"],
    githubUrl: "https://github.com/prashantjaiswal/student-performance-dashboard",
    liveUrl: "#",
    featured: true
  },
  {
    id: "proj-3",
    title: "Sales Data Analysis",
    subtitle: "Business Insights Generator",
    description: "A data analytics project that cleans, analyzes, and visualizes sales data to generate business insights.",
    techStack: ["Python", "SQL", "Excel", "Matplotlib"],
    githubUrl: "https://github.com/prashantjaiswal/sales-data-analysis",
    liveUrl: "#",
    featured: true
  },
  {
    id: "proj-4",
    title: "Personal Portfolio Website",
    subtitle: "3D Interactive Portfolio",
    description: "A modern 3D portfolio website showcasing my skills, education, and projects with smooth animations.",
    techStack: ["HTML", "CSS", "JavaScript"],
    githubUrl: "https://github.com/prashantjaiswal/personal-portfolio",
    liveUrl: "#",
    featured: false
  }
];

export const EXPERIENCE_DATA: ExperienceItem[] = [
  {
    id: "exp-1",
    role: "AI Developer Intern",
    company: "Apex Intelligent Labs",
    duration: "Jan 2026 - Present",
    description: [
      "Engineered high-accuracy analytical ML workflows incorporating robust statistical classifications, improving data extraction rates.",
      "Constructed custom full-stack middleware tools utilizing modern LLM structures to filter unstructured clinical report databases.",
      "Designed clean analytical dashboards displaying real-time model iteration stats and responsive metric layouts."
    ],
    techUsed: ["Python", "PyTorch", "React", "Node.js", "Tailwind CSS"]
  },
  {
    id: "exp-2",
    role: "Full Stack Engineer Intern",
    company: "Synthetix Systems",
    duration: "Jun 2025 - Dec 2025",
    description: [
      "Crafted modular client components with React, optimizing layout rendering patterns and reducing layout shift ratios.",
      "Optimized analytical SQL databases, implementing query caching systems that decreased general database latency metrics.",
      "Maintained structured, peer-reviewed Git branching models and automated code integration workflows."
    ],
    techUsed: ["JavaScript", "React", "Node.js", "Express", "SQL", "Git"]
  },
  {
    id: "exp-3",
    role: "Data Analyst Associate",
    company: "Spectra Metrics",
    duration: "Oct 2024 - Apr 2025",
    description: [
      "Created interactive executive reports on operational status, allowing logistics staff to track warehouse throughput metrics.",
      "Designed and automated Python ETL jobs to cleanly partition monthly transactional datasets.",
      "Supported visual data storytelling initiatives by compiling complex records into highly scannable trend outlines."
    ],
    techUsed: ["Python", "SQL", "Power BI", "Excel", "Data Analysis"]
  }
];

export const TIMELINE_DATA: TimelineItem[] = [
  {
    id: "time-1",
    year: "2023 - Present",
    title: "BS in Artificial Intelligence & Data Science",
    institution: "State Technological University",
    description: "Focusing heavily on Machine Learning, Statistical Modelling, Neural Architecture, and High-Performance Database Systems.",
    type: "education"
  },
  {
    id: "time-2",
    year: "2025",
    title: "Outstanding Hackathon Technical Design",
    institution: "AI Developer Summit",
    description: "Developed and presented a robust edge machine learning framework with real-time classification speedups.",
    type: "achievement"
  },
  {
    id: "time-3",
    year: "2025",
    title: "TensorFlow Developer Certificate",
    institution: "Google",
    description: "Successfully validated proficiency in building, training, and deploying deep learning neural networks, computer vision, and NLP sequence models using TensorFlow.",
    type: "certificate"
  },
  {
    id: "time-4",
    year: "2024",
    title: "Deep Learning Specialization",
    institution: "DeepLearning.AI",
    description: "Completed series of five courses on foundational structure of neural networks, hyperparameter tuning, structuring ML projects, and sequence models.",
    type: "certificate"
  }
];
