import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Mail, Github, Linkedin, Twitter, Send, CheckCircle, ShieldCheck, Lock } from "lucide-react";

export function ContactSection() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  const validateForm = () => {
    const freshErrors: { [key: string]: string } = {};
    if (!name.trim()) freshErrors.name = "Please enter your name";
    if (!email.trim() || !/\S+@\S+\.\S+/.test(email)) freshErrors.email = "Please enter a valid email address";
    if (!message.trim()) freshErrors.message = "Please enter your message";
    setErrors(freshErrors);
    return Object.keys(freshErrors).length === 0;
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
    }, 1200);
  };

  const socialLinks = [
    { name: "LinkedIn", icon: Linkedin, url: "https://linkedin.com/in/prashant-jaiswal", color: "hover:text-blue-400 hover:border-blue-500/30" },
    { name: "GitHub", icon: Github, url: "https://github.com/prashantjaiswal", color: "hover:text-zinc-200 hover:border-zinc-500/30" },
    { name: "Email", icon: Mail, url: "mailto:prashantjai09@gmail.com", color: "hover:text-cyan-400 hover:border-cyan-500/30" },
    { name: "X (Twitter)", icon: Twitter, url: "https://x.com/prashantjaiswal", color: "hover:text-sky-400 hover:border-sky-500/30" }
  ];

  return (
    <section id="contact" className="py-24 px-6 md:px-12 max-w-7xl mx-auto relative z-10">
      {/* SECTION HEADER */}
      <div className="flex flex-col items-center text-center space-y-3 mb-16">
        <div className="inline-flex items-center gap-1.5 bg-blue-950/40 px-3.5 py-1.5 rounded-full border border-blue-500/20 text-blue-400 font-mono text-[10px] uppercase font-bold tracking-wider">
          <Mail className="w-3.5 h-3.5 text-blue-500" />
          Get In Touch
        </div>
        <h2 className="text-3xl md:text-5xl font-display font-black tracking-tight uppercase text-white">
          CONTACT <span className="bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">ME</span>
        </h2>
        <p className="font-sans text-xs md:text-sm text-zinc-400 max-w-2xl leading-relaxed">
          I would love to hear about internship opportunities, client projects, or technical collaboration interests. Feel free to reach out!
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
        {/* LEFT COLUMN: INTRO & SOCIAL DECK */}
        <div className="lg:col-span-5 space-y-8 text-left">
          <div className="border border-white/10 bg-[#11182B]/60 backdrop-blur-xl p-6 md:p-8 rounded-2xl relative shadow-[0_0_40px_rgba(0,0,0,0.5)]">
            <h3 className="font-display font-bold text-white text-lg uppercase tracking-wider mb-3">
              Let's Connect
            </h3>
            <p className="font-sans text-xs text-zinc-400 leading-relaxed mb-6">
              I am actively looking for developer internships, data analyst roles, and AI research support opportunities. Let's build something exceptional.
            </p>

            {/* DIRECT COM CHANNELS */}
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-white/5 border border-white/10 flex items-center gap-4 hover:border-blue-500/40 transition-all">
                <div className="w-10 h-10 rounded-lg bg-blue-950/40 border border-blue-500/20 flex items-center justify-center text-blue-400">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <span className="block font-mono text-[9px] font-bold text-zinc-400 uppercase tracking-widest">SEND EMAIL</span>
                  <a href="mailto:prashantjai09@gmail.com" className="font-mono text-sm text-white hover:text-blue-400 font-bold transition-colors">
                    prashantjai09@gmail.com
                  </a>
                </div>
              </div>
            </div>

            {/* SOCIAL NETWORKS */}
            <div className="mt-8 space-y-3">
              <h4 className="font-mono text-[10px] text-zinc-400 uppercase tracking-widest block font-bold">
                Online Profiles
              </h4>
              <div className="grid grid-cols-2 gap-3">
                {socialLinks.map((social) => {
                  const Icon = social.icon;
                  return (
                    <a
                      key={social.name}
                      href={social.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={`p-3 rounded-xl bg-white/5 border border-white/10 flex items-center gap-2 text-xs text-zinc-400 transition-all hover:bg-white/10 ${social.color}`}
                    >
                      <Icon className="w-4 h-4" />
                      <span className="font-sans font-medium">{social.name}</span>
                    </a>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: MESSAGE CARD (Form) */}
        <div className="lg:col-span-7">
          <div className="border border-white/10 bg-[#11182B]/60 backdrop-blur-xl p-6 md:p-8 rounded-2xl relative shadow-[0_0_40px_rgba(0,0,0,0.5)] text-left">
            {!isSuccess ? (
              <form onSubmit={handleFormSubmit} className="space-y-4">
                {/* NAME INPUT */}
                <div>
                  <label className="font-mono text-[9px] text-zinc-400 uppercase block mb-1.5 font-bold">
                    Your Name
                  </label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. John Doe"
                    className="w-full bg-[#080B15]/50 border border-white/10 focus:border-blue-500 rounded-xl px-3.5 py-3 text-xs text-white placeholder-zinc-600 outline-none transition-colors font-sans"
                  />
                  {errors.name && <span className="font-mono text-[9px] text-red-500 mt-1 block">{errors.name}</span>}
                </div>

                {/* EMAIL INPUT */}
                <div>
                  <label className="font-mono text-[9px] text-zinc-400 uppercase block mb-1.5 font-bold">
                    Email Address
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="e.g. johndoe@company.com"
                    className="w-full bg-[#080B15]/50 border border-white/10 focus:border-blue-500 rounded-xl px-3.5 py-3 text-xs text-white placeholder-zinc-600 outline-none transition-colors font-sans"
                  />
                  {errors.email && <span className="font-mono text-[9px] text-red-500 mt-1 block">{errors.email}</span>}
                </div>

                {/* SUBJECT INPUT */}
                <div>
                  <label className="font-mono text-[9px] text-zinc-400 uppercase block mb-1.5 font-bold">
                    Subject
                  </label>
                  <input
                    type="text"
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    placeholder="e.g. Collaboration Proposal / Internship Position"
                    className="w-full bg-[#080B15]/50 border border-white/10 focus:border-blue-500 rounded-xl px-3.5 py-3 text-xs text-white placeholder-zinc-600 outline-none transition-colors font-sans"
                  />
                </div>

                {/* MESSAGE TEXTAREA */}
                <div>
                  <label className="font-mono text-[9px] text-zinc-400 uppercase block mb-1.5 font-bold">
                    Message
                  </label>
                  <textarea
                    rows={4}
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Hi Prashant, I would love to talk about..."
                    className="w-full bg-[#080B15]/50 border border-white/10 focus:border-blue-500 rounded-xl px-3.5 py-3 text-xs text-white placeholder-zinc-600 outline-none transition-colors font-sans resize-none"
                  />
                  {errors.message && <span className="font-mono text-[9px] text-red-500 mt-1 block">{errors.message}</span>}
                </div>

                {/* CONTROL BUTTONS */}
                <div className="pt-2">
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-505 text-white font-display font-black text-xs uppercase tracking-widest py-3.5 rounded-xl border border-blue-400/20 transition-all flex items-center justify-center gap-2 cursor-pointer shadow-[0_0_15px_rgba(59,130,246,0.15)] disabled:opacity-50"
                  >
                    {isSubmitting ? (
                      <>
                        <span className="w-3.5 h-3.5 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                        <span>Sending Transmission...</span>
                      </>
                    ) : (
                      <>
                        <Send className="w-3.5 h-3.5" />
                        <span>Send Message</span>
                      </>
                    )}
                  </button>
                </div>

                <div className="flex items-center justify-center gap-1.5 text-zinc-650 font-mono text-[8px] tracking-wide uppercase pt-2">
                  <Lock className="w-3 h-3 text-zinc-600" />
                  <span>Encrypted Channel // Direct Outbox</span>
                </div>
              </form>
            ) : (
              /* SUCCESS SCREEN READOUT MODE */
              <div className="text-center py-6 space-y-6">
                <div className="w-14 h-14 bg-blue-950/40 border border-blue-500/30 rounded-full flex items-center justify-center mx-auto shadow-[0_0_24px_rgba(59,130,246,0.3)]">
                  <ShieldCheck className="w-6 h-6 text-blue-400" />
                </div>

                <div className="space-y-2">
                  <span className="font-mono text-[80%] text-blue-400 block uppercase font-bold tracking-widest">TRANSMISSION DELIVERED</span>
                  <h3 className="text-xl md:text-2xl font-display font-black text-white uppercase tracking-tight">Message Received!</h3>
                  <p className="font-sans text-xs text-zinc-400 leading-relaxed max-w-sm mx-auto">
                    Thanks <strong className="text-white">{name}</strong>, your message has been sent directly to Prashant. A response will be dispatched soon.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    setIsSuccess(false);
                    setName("");
                    setSubject("");
                    setMessage("");
                  }}
                  className="cursor-pointer font-display font-bold text-xs uppercase tracking-wider bg-zinc-900 override-style hover:bg-zinc-800 hover:text-white border border-zinc-800 text-zinc-300 px-6 py-3 rounded-xl transition-all"
                >
                  Send another message
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
