import React, { useEffect, useRef } from "react";
import * as THREE from "three";

export function ThreeBackground() {
  const containerRef = useRef<HTMLDivElement>(null);
  const mouseRef = useRef({ x: 0, y: 0, targetX: 0, targetY: 0 });

  useEffect(() => {
    if (!containerRef.current) return;

    // 1. Setup Scene, Camera, and Renderer
    const container = containerRef.current;
    const width = container.clientWidth;
    const height = container.clientHeight;

    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x0b1020, 0.015);

    const camera = new THREE.PerspectiveCamera(60, width / height, 0.1, 100);
    camera.position.z = 18;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(width, height);
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;
    container.appendChild(renderer.domElement);

    // 2. Add Floating Objects Group
    const group = new THREE.Group();
    scene.add(group);

    // Object A: Glass-wireframe Torus Knot (Centerpiece)
    const torusKnotGeo = new THREE.TorusKnotGeometry(3, 0.8, 120, 32);
    const torusKnotMat = new THREE.MeshPhysicalMaterial({
      color: 0x3b82f6, // deep blue
      emissive: 0x2563eb, 
      emissiveIntensity: 0.8,
      roughness: 0.1,
      metalness: 0.3,
      transparent: true,
      opacity: 0.8,
      wireframe: true,
    });
    const torusKnot = new THREE.Mesh(torusKnotGeo, torusKnotMat);
    torusKnot.position.set(0, 0, 0);
    group.add(torusKnot);

    // Object B: Glowing Crystalline Octahedron (Floating secondary)
    const octGeo = new THREE.OctahedronGeometry(1.8, 1);
    const octMat = new THREE.MeshPhysicalMaterial({
      color: 0x06b6d4, // Cyan
      emissive: 0x0891b2,
      emissiveIntensity: 0.8,
      roughness: 0.1,
      metalness: 0.8,
      transparent: true,
      opacity: 0.7,
      wireframe: true,
    });
    const octahedron = new THREE.Mesh(octGeo, octMat);
    octahedron.position.set(-8, 5, -3);
    group.add(octahedron);

    // Object C: Transparent wireframe Dodecahedron (Floating left-bottom)
    const dodeGeo = new THREE.DodecahedronGeometry(2, 0);
    const dodeMat = new THREE.MeshPhysicalMaterial({
      color: 0x8b5cf6, // Purple
      emissive: 0x7c3aed,
      emissiveIntensity: 0.8,
      roughness: 0.2,
      metalness: 0.6,
      transparent: true,
      opacity: 0.7,
      wireframe: true,
    });
    const dodecahedron = new THREE.Mesh(dodeGeo, dodeMat);
    dodecahedron.position.set(7, -5, -2);
    group.add(dodecahedron);

    // 3. Ambient & Point Starfields
    const starsCount = 800;
    const starsGeo = new THREE.BufferGeometry();
    const positions = new Float32Array(starsCount * 3);

    for (let i = 0; i < starsCount * 3; i += 3) {
      positions[i] = (Math.random() - 0.5) * 50;     // X
      positions[i + 1] = (Math.random() - 0.5) * 50; // Y
      positions[i + 2] = (Math.random() - 0.5) * 50; // Z
    }

    starsGeo.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    const starsMat = new THREE.PointsMaterial({
      size: 0.15,
      color: 0x60a5fa,
      transparent: true,
      opacity: 0.9,
    });
    const stars = new THREE.Points(starsGeo, starsMat);
    scene.add(stars);

    // 4. Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.8);
    scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0x3b82f6, 2.0);
    dirLight1.position.set(5, 10, 7);
    scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0x22d3ee, 1.5);
    dirLight2.position.set(-10, -5, -5);
    scene.add(dirLight2);

    const purplePointLight = new THREE.PointLight(0xa855f7, 4, 40);
    purplePointLight.position.set(0, 0, 5);
    scene.add(purplePointLight);

    // 5. Track Mouse Move
    const handleMouseMove = (e: MouseEvent) => {
      const windowWidth = window.innerWidth;
      const windowHeight = window.innerHeight;
      mouseRef.current.targetX = (e.clientX / windowWidth - 0.5) * 1.5;
      mouseRef.current.targetY = -(e.clientY / windowHeight - 0.5) * 1.5;
    };
    window.addEventListener("mousemove", handleMouseMove);

    // Handle touch move for mobile devices
    const handleTouchMove = (e: TouchEvent) => {
      if (e.touches.length > 0) {
        const touch = e.touches[0];
        const windowWidth = window.innerWidth;
        const windowHeight = window.innerHeight;
        mouseRef.current.targetX = (touch.clientX / windowWidth - 0.5) * 1.2;
        mouseRef.current.targetY = -(touch.clientY / windowHeight - 0.5) * 1.2;
      }
    };
    window.addEventListener("touchmove", handleTouchMove, { passive: true });

    // 6. Resize Observer
    const handleResize = () => {
      const newWidth = container.clientWidth;
      const newHeight = container.clientHeight;
      camera.aspect = newWidth / newHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(newWidth, newHeight);
    };

    const resizeObserver = new ResizeObserver(() => {
      handleResize();
    });
    resizeObserver.observe(container);

    // 7. Core Animation Loop
    const clock = new THREE.Clock();

    let reqId = 0;
    const animate = () => {
      reqId = requestAnimationFrame(animate);

      const elapsedTime = clock.getElapsedTime();

      // Smooth mouse interpolation / damping for pleasant inertia
      mouseRef.current.x += (mouseRef.current.targetX - mouseRef.current.x) * 0.05;
      mouseRef.current.y += (mouseRef.current.targetY - mouseRef.current.y) * 0.05;

      // Rotate primary objects
      torusKnot.rotation.x = elapsedTime * 0.15;
      torusKnot.rotation.y = elapsedTime * 0.2;
      
      octahedron.rotation.y = -elapsedTime * 0.1;
      octahedron.rotation.z = elapsedTime * 0.15;
      octahedron.position.y = 4 + Math.sin(elapsedTime * 0.5) * 0.8;

      dodecahedron.rotation.x = -elapsedTime * 0.12;
      dodecahedron.rotation.y = -elapsedTime * 0.15;
      dodecahedron.position.y = -4 + Math.cos(elapsedTime * 0.4) * 0.6;

      // Soft mouse-driven camera panning
      camera.position.x = mouseRef.current.x * 4;
      camera.position.y = mouseRef.current.y * 4;
      camera.lookAt(0, 0, 0);

      // Rotate background stars group slowly
      stars.rotation.y = elapsedTime * 0.015;

      // Constant slow group drift
      group.rotation.z = elapsedTime * 0.02;

      renderer.render(scene, camera);
    };

    animate();

    // 8. Cleanup on component destruction
    return () => {
      cancelAnimationFrame(reqId);
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("touchmove", handleTouchMove);
      resizeObserver.disconnect();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
      scene.clear();
      renderer.dispose();
    };
  }, []);

  return (
    <div 
      ref={containerRef} 
      className="absolute inset-0 w-full h-full overflow-hidden pointer-events-none z-0"
    />
  );
}
