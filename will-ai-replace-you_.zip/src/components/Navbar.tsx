import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Menu, X, ArrowUpRight, Cpu } from "lucide-react";

interface NavbarProps {
  activeSection: string;
  onNavigate: (sectionId: string) => void;
}

export function Navbar({ activeSection, onNavigate }: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { name: "Home", id: "home" },
    { name: "About", id: "about" },
    { name: "Skills", id: "skills" },
    { name: "Projects", id: "projects" },
    { name: "Education", id: "education" },
    { name: "Resume", id: "resume" },
    { name: "Contact", id: "contact" }
  ];

  const handleLinkClick = (id: string) => {
    onNavigate(id);
    setIsOpen(false);
  };

  return (
    <>
      <header
        className={`fixed top-0 left-0 w-full z-40 transition-all duration-300 ${
          isScrolled 
            ? "bg-black/85 backdrop-blur-md border-b border-zinc-800/60 shadow-[0_4px_30px_rgba(0,0,0,0.5)]" 
            : "bg-transparent border-b border-transparent"
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 h-16 md:h-20 flex items-center justify-between">
          {/* Logo / Trademark */}
          <button 
            onClick={() => handleLinkClick("home")}
            className="flex items-center gap-2.5 group cursor-pointer"
          >
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-blue-600 to-indigo-500 flex items-center justify-center border border-blue-400/20 shadow-[0_0_15px_rgba(59,130,246,0.2)] transition-transform duration-300 group-hover:rotate-6">
              <Cpu className="w-5 h-5 text-white" />
            </div>
            <span className="font-display font-bold text-white text-base md:text-lg uppercase tracking-wider">
              PRASHANT <span className="text-blue-500 font-mono">JAISWAL</span>
            </span>
          </button>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1 bg-[#080B15]/80 border border-white/10 rounded-full px-2 py-1.5 shadow-lg">
            {navLinks.map((link) => {
              const isActive = activeSection === link.id;
              return (
                <button
                  key={link.id}
                  onClick={() => handleLinkClick(link.id)}
                  className={`relative px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-widest transition-colors cursor-pointer ${
                    isActive ? "text-white" : "text-zinc-400 hover:text-white hover:bg-white/5"
                  }`}
                >
                  {isActive && (
                    <motion.div
                      layoutId="activeNavBG"
                      className="absolute inset-0 bg-blue-600/30 border border-blue-500/50 rounded-full"
                      transition={{ type: "spring", stiffness: 380, damping: 30 }}
                    />
                  )}
                  {link.name}
                </button>
              );
            })}
          </nav>

          {/* Right Action Trigger */}
          <div className="hidden lg:flex items-center">
            <button
              onClick={() => handleLinkClick("contact")}
              className="cursor-pointer bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-505 text-white border border-blue-400/20 px-5 py-2 rounded-lg text-xs font-display font-medium uppercase tracking-wider flex items-center gap-1.5 shadow-[0_0_15px_rgba(59,130,246,0.25)] transition-all"
            >
              <span>Hire Me</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="lg:hidden text-zinc-400 hover:text-white p-1.5 rounded-lg border border-zinc-900 transition-colors cursor-pointer"
            aria-label="Toggle Navigation Menu"
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </header>

      {/* Mobile overlay drawer */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="fixed inset-x-0 top-16 bg-neutral-950/98 backdrop-blur-xl border-b border-zinc-900 z-40 lg:hidden py-6 px-6 space-y-4 shadow-2xl"
          >
            <div className="flex flex-col gap-2.5">
              {navLinks.map((link) => {
                const isActive = activeSection === link.id;
                return (
                  <button
                    key={link.id}
                    onClick={() => handleLinkClick(link.id)}
                    className={`w-full py-2.5 px-4 rounded-lg text-left text-xs uppercase tracking-widest font-heading flex justify-between items-center bg-zinc-900/40 border transition-all ${
                      isActive 
                        ? "border-blue-500/30 text-blue-400 bg-blue-950/15" 
                        : "border-zinc-800/40 text-zinc-400 hover:text-white"
                    }`}
                  >
                    <span>{link.name}</span>
                    <span className="text-[9px] font-mono opacity-50">/ 0{navLinks.indexOf(link) + 1}</span>
                  </button>
                );
              })}
              <button
                onClick={() => handleLinkClick("contact")}
                className="w-full py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-lg text-xs font-display uppercase tracking-widest font-medium text-center shadow-lg"
              >
                Get In Touch
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
