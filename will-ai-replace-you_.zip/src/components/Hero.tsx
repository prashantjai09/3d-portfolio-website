import React, { useState, useEffect } from "react";
import { motion } from "motion/react";
import { ArrowDown, Cpu, Sparkles, FolderGit2, Mail, Terminal, FileText } from "lucide-react";

interface HeroProps {
  onScrollToSection: (sectionId: string) => void;
}

export function Hero({ onScrollToSection }: HeroProps) {
  const [typedText, setTypedText] = useState("");
  const [textIndex, setTextIndex] = useState(0);
  const [letterIndex, setLetterIndex] = useState(0);
  const [isDeleting, setIsDeleting] = useState(false);

  const phrases = [
    "BS in Artificial Intelligence & Data Science Student",
    "Full Stack Developer",
    "Data Analyst Associate",
    "Machine Learning Architect"
  ];

  // Professional automatic typewriter loop
  useEffect(() => {
    let timer: NodeJS.Timeout;
    const currentPhrase = phrases[textIndex];

    if (isDeleting) {
      timer = setTimeout(() => {
        setTypedText(currentPhrase.substring(0, letterIndex - 1));
        setLetterIndex((prev) => prev - 1);
      }, 30);
    } else {
      timer = setTimeout(() => {
        setTypedText(currentPhrase.substring(0, letterIndex + 1));
        setLetterIndex((prev) => prev + 1);
      }, 60);
    }

    if (!isDeleting && letterIndex === currentPhrase.length) {
      timer = setTimeout(() => setIsDeleting(true), 1800); // Wait before delete
    } else if (isDeleting && letterIndex === 0) {
      setIsDeleting(false);
      setTextIndex((prev) => (prev + 1) % phrases.length);
    }

    return () => clearTimeout(timer);
  }, [letterIndex, isDeleting, textIndex]);

  return (
    <div className="relative min-h-screen flex flex-col justify-between overflow-hidden px-6 md:px-12 py-12 select-none">
      
      {/* 1. TOP MARGINS LOGS & METADATA (CLEANED) */}
      <div className="w-full max-w-7xl mx-auto flex items-center justify-between relative z-10">
        <div className="flex items-center gap-2 font-mono text-[10px] text-zinc-400 tracking-wider">
          <Terminal className="w-4 h-4 text-blue-500" />
          <span>PORTFOLIO // ACTIVE</span>
        </div>
        <div className="font-mono text-[10px] text-zinc-400 tracking-wider">
          EST. 2026
        </div>
      </div>

      {/* 2. CHIEF DISPATCH CONTENT */}
      <div className="w-full max-w-7xl mx-auto flex flex-col items-start text-left my-auto relative z-10 space-y-6 pt-12 md:pt-0">
        
        {/* Subtle pill tag */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="inline-flex items-center gap-2 bg-blue-950/20 px-3.5 py-1.5 rounded-full border border-blue-500/15 text-blue-400 font-mono text-[10px] uppercase font-bold tracking-wider"
        >
          <Sparkles className="w-3.5 h-3.5 text-blue-400 animate-pulse" />
          <span>Available for Internships & Projects</span>
        </motion.div>

        {/* Name Large Typography */}
        <div className="space-y-2">
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.1 }}
            className="font-mono text-zinc-400 text-xs uppercase tracking-widest"
          >
            CREATIVE ENGINEER & RESEARCHER
          </motion.p>
          
          <motion.h1
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.15 }}
            className="text-4xl sm:text-6xl md:text-8xl font-display font-black tracking-tight uppercase leading-none text-white"
          >
            Hi, I'm <span className="bg-gradient-to-r from-blue-500 via-cyan-400 to-indigo-400 bg-clip-text text-transparent">Prashant</span>
            <br />
            Jaiswal
          </motion.h1>
        </div>

        {/* Autotyping Subtitle */}
        <div className="h-8 flex items-center">
          <span className="font-mono text-cyan-400 text-sm md:text-lg font-bold tracking-wider">
            &gt; {typedText}
          </span>
          <span className="w-2 h-5 bg-cyan-400 ml-1.5 animate-pulse" />
        </div>

        {/* Short introduction paragraph */}
        <motion.p
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.25 }}
          className="font-sans text-base md:text-lg text-zinc-300 max-w-xl leading-relaxed"
        >
          I execute high-performance machine learning research and construct scalable full-stack web architectures, rendering complex analytics into elegant, responsive digital solutions.
        </motion.p>

        {/* Action button deck */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.35 }}
          className="flex flex-wrap gap-4 pt-3"
        >
          {/* VIEW PROJECTS */}
          <button
            onClick={() => onScrollToSection("projects")}
            className="cursor-pointer bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white border border-blue-400/20 px-6 py-3.5 rounded-xl text-xs sm:text-sm font-bold uppercase tracking-widest flex items-center gap-2 shadow-[0_0_24px_rgba(59,130,246,0.3)] hover:shadow-[0_0_35px_rgba(59,130,246,0.5)] hover:-translate-y-0.5 transition-all"
          >
            <FolderGit2 className="w-4 h-4" />
            <span>View Projects</span>
          </button>

          {/* CONTACT ME */}
          <button
            onClick={() => onScrollToSection("contact")}
            className="cursor-pointer bg-white/5 hover:bg-white/10 text-zinc-100 border border-white/10 hover:border-white/20 px-6 py-3.5 rounded-xl text-xs sm:text-sm font-bold uppercase tracking-widest flex items-center gap-2 hover:-translate-y-0.5 transition-all w-full sm:w-auto justify-center"
          >
            <Mail className="w-4 h-4" />
            <span>Contact Me</span>
          </button>

          {/* RESUME SPEED LINK */}
          <button
            onClick={() => onScrollToSection("resume")}
            className="cursor-pointer bg-[#080B15]/50 hover:bg-[#11182B] text-zinc-100 hover:text-white border border-white/10 hover:border-blue-500/40 px-6 py-3.5 rounded-xl text-xs sm:text-sm font-bold uppercase tracking-widest flex items-center gap-2 hover:-translate-y-0.5 transition-all w-full sm:w-auto justify-center"
          >
            <FileText className="w-4 h-4 text-blue-400" />
            <span>Get Resume</span>
          </button>
        </motion.div>
      </div>

      {/* 3. SCROLL DOWN HINT FOOTER */}
      <div className="w-full max-w-7xl mx-auto flex items-center justify-between relative z-10">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-blue-500 animate-ping" />
          <span className="font-mono text-[10px] sm:text-xs text-zinc-400 font-bold uppercase tracking-wider">
            RECRUITER READY DIRECTORY
          </span>
        </div>

        <button
          onClick={() => onScrollToSection("about")}
          className="flex items-center gap-2 group text-zinc-400 hover:text-white font-mono text-[10px] sm:text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer"
        >
          <span>LEARN MORE</span>
          <ArrowDown className="w-4 h-4 group-hover:translate-y-1 transition-transform" />
        </button>
      </div>

    </div>
  );
}
