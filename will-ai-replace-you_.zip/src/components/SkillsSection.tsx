import React, { useState } from "react";
import { motion } from "motion/react";
import { SKILLS_DATA } from "../data";
import * as LucideIcons from "lucide-react";

export function SkillsSection() {
  const [activeCategory, setActiveCategory] = useState<"all" | "language" | "backend" | "ai-ds" | "tool">("all");

  const categories = [
    { label: "All Skills", id: "all" },
    { label: "Languages", id: "language" },
    { label: "Backend & SQL", id: "backend" },
    { label: "Artificial Intelligence", id: "ai-ds" },
    { label: "Tools & Analytics", id: "tool" }
  ];

  const filteredSkills = SKILLS_DATA.filter(
    (skill) => activeCategory === "all" || skill.category === activeCategory
  );

  return (
    <section id="skills" className="py-24 px-6 md:px-12 max-w-7xl mx-auto relative z-10">
      {/* SECTION HEADER */}
      <div className="flex flex-col items-center text-center space-y-3 mb-12">
        <div className="inline-flex items-center gap-1.5 bg-blue-950/40 px-3.5 py-1.5 rounded-full border border-blue-500/20 text-blue-400 font-mono text-[10px] uppercase font-bold tracking-wider">
          <LucideIcons.Wrench className="w-3.5 h-3.5 text-blue-500" />
          Technical Toolkit
        </div>
        <h2 className="text-3xl md:text-5xl font-display font-black tracking-tight uppercase text-white">
          SKILLS & <span className="bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">COMPETENCIES</span>
        </h2>
        <p className="font-sans text-xs md:text-sm text-zinc-400 max-w-2xl leading-relaxed">
          I balance software engineering principles with data-driven predictive architectures and deep learning applications.
        </p>
      </div>

      {/* FILTER DECK */}
      <div className="flex flex-wrap justify-center gap-2 mb-12 max-w-4xl mx-auto">
        {categories.map((cat) => {
          const isActive = activeCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id as any)}
              className={`px-4 py-2 rounded-lg text-xs font-mono uppercase tracking-wider transition-all cursor-pointer border ${
                isActive 
                  ? "bg-blue-600/20 border-blue-500 text-blue-400 shadow-[0_0_12px_rgba(59,130,246,0.3)]" 
                  : "bg-white/5 border-white/10 text-zinc-400 hover:text-white hover:bg-white/10 hover:border-white/20"
              }`}
            >
              {cat.label}
            </button>
          );
        })}
      </div>

      {/* GRID DECK OF CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {filteredSkills.map((skill, idx) => {
          // Dynamic icon retrieval safely from lucide packages
          const IconComponent = (LucideIcons as any)[skill.icon] || LucideIcons.FileCode;

          return (
            <motion.div
              layout
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.04, duration: 0.35, ease: "easeOut" }}
              key={skill.name}
              className="border border-white/10 bg-[#11182B]/60 backdrop-blur-xl p-6 rounded-2xl relative shadow-2xl group hover:border-blue-500/50 hover:bg-[#1d284a]/80 transition-all text-left"
            >
              {/* Decorative radial card hover backdrop */}
              <div className="absolute inset-0 bg-blue-500/10 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none rounded-2xl blur-lg" />

              <div className="flex items-center justify-between gap-4 mb-4 relative z-10">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-950/65 to-zinc-900 border border-blue-500/10 flex items-center justify-center text-blue-400 group-hover:text-cyan-400 group-hover:border-blue-400/30 transition-all">
                    <IconComponent className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-display font-bold text-white text-base leading-tight group-hover:text-blue-300 transition-colors">
                      {skill.name}
                    </h4>
                    <span className="font-mono text-[9px] font-bold text-zinc-400 uppercase tracking-widest">
                      {skill.category.replace("-", "/")}
                    </span>
                  </div>
                </div>

                {/* CIRCULAR INDICATOR GAUGE */}
                <div className="relative w-11 h-11 flex items-center justify-center">
                  <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                    <path
                      className="text-white/10"
                      strokeWidth="2.5"
                      stroke="currentColor"
                      fill="none"
                      d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    />
                    <motion.path
                      initial={{ strokeDasharray: "0 100" }}
                      whileInView={{ strokeDasharray: `${skill.level} 100` }}
                      viewport={{ once: true }}
                      transition={{ duration: 1, ease: "easeOut" }}
                      className="text-blue-500"
                      strokeWidth="2.5"
                      strokeLinecap="round"
                      stroke="currentColor"
                      fill="none"
                      d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    />
                  </svg>
                  <span className="absolute font-mono text-[9px] font-bold text-zinc-200 group-hover:text-white transition-colors">
                    {skill.level}%
                  </span>
                </div>
              </div>

              {/* LINEAR PROGRESS SLIDER */}
              <div className="space-y-1.5 relative z-10">
                <div className="h-1 bg-white/10 rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    whileInView={{ width: `${skill.level}%` }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.8, delay: 0.05, ease: "easeOut" }}
                    className="h-full bg-gradient-to-r from-blue-500 to-cyan-500 group-hover:from-blue-400 group-hover:to-cyan-400 transition-all rounded-full"
                  />
                </div>
                <div className="flex justify-between items-center text-[9px] font-mono font-bold text-zinc-400 group-hover:text-zinc-300 transition-colors">
                  <span>PROFICIENCY</span>
                  <span>ACTIVE</span>
                </div>
              </div>

            </motion.div>
          );
        })}
      </div>
    </section>
  );
}
