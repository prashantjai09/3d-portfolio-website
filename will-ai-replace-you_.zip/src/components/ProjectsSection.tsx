import React, { useState, useRef } from "react";
import { motion } from "motion/react";
import { PROJECTS_DATA } from "../data";
import { FolderGit2, Github, ExternalLink, Cpu } from "lucide-react";

// Individual 3D Tilt Card Component for pristine interactive precision
function ProjectCard({ project }: { project: typeof PROJECTS_DATA[0] }) {
  const cardRef = useRef<HTMLDivElement>(null);
  const [rotate, setRotate] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const card = cardRef.current;
    const rect = card.getBoundingClientRect();
    
    // Calculate mouse position relative to card coordinates (-0.5 to 0.5)
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;

    // Apply tilt calculations (rotate up to 10 degrees)
    setRotate({
      x: -y * 8,
      y: x * 8,
    });
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
    setRotate({ x: 0, y: 0 });
  };

  // Helper to draw a specific aesthetic SVG mock schema based on project ID
  const renderInteractiveSchema = (id: string) => {
    switch (id) {
      case "proj-1":
        return (
          <div className="relative w-full h-full">
            <svg className="w-full h-full opacity-80" viewBox="0 0 100 60" fill="none" stroke="currentColor">
              <g className="text-blue-500/30">
                <circle cx="50" cy="30" r="18" strokeWidth="0.5" strokeDasharray="2 1" />
                <circle cx="50" cy="30" r="12" strokeWidth="0.5" />
                <path d="M50 5 V 55 M20 30 H 80" strokeWidth="0.25" strokeDasharray="3 3" />
              </g>
              <g className="text-cyan-400">
                <path d="M40 23 L45 30 L50 25 L55 35 L60 30" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round" />
              </g>
              <circle cx="50" cy="25" r="1.5" fill="#22d3ee" className="animate-pulse" />
            </svg>
            <span className="absolute bottom-2 right-3 font-mono text-[8px] text-zinc-400 font-bold uppercase tracking-wider">Classification Engine</span>
          </div>
        );
      case "proj-2":
        return (
          <div className="relative w-full h-full">
            <svg className="w-full h-full opacity-80" viewBox="0 0 100 60" fill="none" stroke="currentColor">
              <g className="text-purple-500/20">
                <rect x="15" y="10" width="70" height="40" rx="3" strokeWidth="0.5" />
                <path d="M15 20 H 85 M15 40 H 85 M50 10 V 50" strokeWidth="0.25" strokeDasharray="2 2" />
              </g>
              <g className="text-cyan-400">
                <path d="M 25 35 Q 40 15, 55 42 T 75 18" strokeWidth="1" strokeLinecap="round" />
                <circle cx="55" cy="42" r="2" fill="#22d3ee" />
                <circle cx="75" cy="18" r="2" fill="#d946ef" className="animate-ping" />
              </g>
            </svg>
            <span className="absolute bottom-2 right-3 font-mono text-[8px] text-zinc-400 font-bold uppercase tracking-wider">Spatial Routing Map</span>
          </div>
        );
      case "proj-3":
        return (
          <div className="relative w-full h-full">
            <svg className="w-full h-full opacity-80" viewBox="0 0 100 60" fill="none" stroke="currentColor">
              <g className="text-blue-500/20">
                <circle cx="25" cy="15" r="3" strokeWidth="0.5" />
                <circle cx="25" cy="30" r="3" strokeWidth="0.5" />
                <circle cx="25" cy="45" r="3" strokeWidth="0.5" />
                
                <circle cx="50" cy="20" r="3" strokeWidth="0.5" />
                <circle cx="50" cy="40" r="3" strokeWidth="0.5" />

                <circle cx="75" cy="30" r="3" strokeWidth="0.5" />
              </g>
              <g className="text-blue-500/40" strokeWidth="0.3">
                <line x1="28" y1="15" x2="47" y2="20" />
                <line x1="28" y1="15" x2="47" y2="40" />
                <line x1="28" y1="30" x2="47" y2="20" />
                <line x1="28" y1="30" x2="47" y2="40" />
                <line x1="28" y1="45" x2="47" y2="20" />
                <line x1="28" y1="45" x2="47" y2="40" />

                <line x1="53" y1="20" x2="72" y2="30" />
                <line x1="53" y1="40" x2="72" y2="30" />
              </g>
              <circle cx="75" cy="30" r="2" fill="#3b82f6" className="animate-pulse" />
            </svg>
            <span className="absolute bottom-2 right-3 font-mono text-[8px] text-zinc-400 font-bold uppercase tracking-wider">Feedforward Model</span>
          </div>
        );
      default:
        return (
          <div className="relative w-full h-full">
            <svg className="w-full h-full opacity-80" viewBox="0 0 100 60" fill="none" stroke="currentColor">
              <g className="text-zinc-800" strokeWidth="0.5">
                <line x1="10" y1="10" x2="90" y2="50" />
                <line x1="10" y1="50" x2="90" y2="10" />
                <rect x="35" y="15" width="30" height="30" strokeWidth="0.5" strokeDasharray="3 3" />
              </g>
              <g className="text-amber-500">
                <circle cx="50" cy="30" r="6" strokeWidth="0.75" />
                <polygon points="50,22 55,34 45,34" strokeWidth="0.5" fill="none" />
              </g>
            </svg>
            <span className="absolute bottom-2 right-3 font-mono text-[8px] text-zinc-400 font-bold uppercase tracking-wider">Analytics Grid</span>
          </div>
        );
    }
  };

  return (
    <div
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={handleMouseLeave}
      style={{
        transform: `perspective(1000px) rotateX(${rotate.x}deg) rotateY(${rotate.y}deg) scale3d(${isHovered ? 1.015 : 1}, ${isHovered ? 1.015 : 1}, 1)`,
        transition: isHovered ? "none" : "transform 0.4s ease-out",
      }}
      className="border border-white/10 bg-[#11182B]/60 backdrop-blur-xl rounded-2xl overflow-hidden shadow-2xl relative flex flex-col justify-between h-full group"
    >
      {/* GLOW OVERLAY UNDER MOUSE */}
      <div className="absolute inset-0 bg-gradient-to-r from-blue-600/10 to-cyan-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      {/* Blue strip tracker */}
      <div className="h-1 w-full bg-gradient-to-r from-blue-500 via-cyan-400 to-transparent scale-x-0 group-hover:scale-x-100 transition-transform origin-left duration-300" />

      {/* CORE BODY CONTAINER */}
      <div>
        {/* INTERACTIVE COMPONENT CANVAS SCHEMATIC (Image representation) */}
        <div className="h-44 bg-[#080B15]/80 border-b border-white/10 relative flex items-center justify-center overflow-hidden">
          {/* Animated network lines map backdrops */}
          <div className="absolute inset-x-0 top-0 h-full w-full blueprint-grid-fine opacity-20" />
          
          <div className="relative w-full h-full flex items-center justify-center">
            {renderInteractiveSchema(project.id)}
          </div>

          <div className="absolute top-3 left-3 bg-[#0B1020]/90 border border-white/10 rounded px-2.5 py-1 font-mono text-[8px] text-blue-400 tracking-wider flex items-center gap-1">
            <Cpu className="w-2.5 h-2.5 text-blue-500" />
            <span>PORTFOLIO CODE: {project.id.toUpperCase()}</span>
          </div>
        </div>

        {/* METRICS & DESCRIPTION PANEL */}
        <div className="p-6 text-left space-y-3">
          <div className="space-y-1">
            <span className="font-mono text-[9px] text-cyan-500 uppercase tracking-widest font-bold">
              {project.subtitle}
            </span>
            <h3 className="font-display font-black text-white text-lg md:text-xl uppercase tracking-tight group-hover:text-blue-400 transition-colors">
              {project.title}
            </h3>
          </div>

          <p className="font-sans text-xs text-zinc-400 leading-relaxed">
            {project.description}
          </p>

          {/* TAGS PILLS */}
          <div className="flex flex-wrap gap-1.5 pt-2">
            {project.techStack.map((tech) => (
              <span
                key={tech}
                className="bg-white/5 border border-white/10 px-2.5 py-0.5 rounded text-[8px] font-mono text-zinc-400 uppercase tracking-wider group-hover:border-blue-500/30 group-hover:bg-blue-500/10 group-hover:text-white transition-all"
              >
                {tech}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* FOOTER ACTIONS DECK */}
      <div className="p-6 pt-0 border-t border-white/10 mt-auto flex items-center justify-between bg-white/5 py-4">
        <a
          href={project.githubUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="text-zinc-300 hover:text-white flex items-center gap-1.5 font-mono text-[11px] font-bold uppercase tracking-widest transition-colors"
        >
          <Github className="w-4 h-4" />
          <span>Source Code</span>
        </a>

        {project.liveUrl !== "#" ? (
          <a
            href={project.liveUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="text-blue-400 hover:text-cyan-400 flex items-center gap-1.5 font-mono text-[11px] uppercase tracking-wider font-bold transition-colors"
          >
            <span>Live Demo</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        ) : (
          <span className="text-zinc-400 flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-wider font-bold">
            <span>Core Model</span>
            <span className="w-1.5 h-1.5 rounded-full bg-blue-500" />
          </span>
        )}
      </div>
    </div>
  );
}

export function ProjectsSection() {
  return (
    <section id="projects" className="py-24 px-6 md:px-12 max-w-7xl mx-auto relative z-10">
      {/* SECTION HEADER */}
      <div className="flex flex-col items-center text-center space-y-3 mb-16">
        <div className="inline-flex items-center gap-1.5 bg-blue-950/40 px-3.5 py-1.5 rounded-full border border-blue-500/20 text-blue-400 font-mono text-[10px] uppercase font-bold tracking-wider">
          <FolderGit2 className="w-3.5 h-3.5 text-blue-500" />
          Selected Work
        </div>
        <h2 className="text-3xl md:text-5xl font-display font-black tracking-tight uppercase text-white">
          FEATURED <span className="bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">PROJECTS</span>
        </h2>
        <p className="font-sans text-xs md:text-sm text-zinc-400 max-w-2xl leading-relaxed">
          Explore production codebases and predictive utilities engineered with robust full-stack capabilities and detailed interactive diagnostics.
        </p>
      </div>

      {/* THREE-DIMENSIONAL DECK LAYOUT */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {PROJECTS_DATA.map((project, idx) => (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: idx * 0.1, duration: 0.5 }}
            key={project.id}
          >
            <ProjectCard project={project} />
          </motion.div>
        ))}
      </div>
    </section>
  );
}
