import React, { useState, useEffect } from "react";
import { ArrowUp, Heart, Cpu } from "lucide-react";

export function Footer() {
  const [showScroll, setShowScroll] = useState(false);

  useEffect(() => {
    const checkScrollTop = () => {
      if (!showScroll && window.scrollY > 400) {
        setShowScroll(true);
      } else if (showScroll && window.scrollY <= 400) {
        setShowScroll(false);
      }
    };
    window.addEventListener("scroll", checkScrollTop);
    return () => window.removeEventListener("scroll", checkScrollTop);
  }, [showScroll]);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <footer className="relative z-10 border-t border-white/5 bg-[#080B15]/80 backdrop-blur-md py-12 px-6">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
        
        {/* LEFT BRAND CORNER */}
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded bg-blue-900/40 border border-blue-500/30 flex items-center justify-center text-blue-400">
            <Cpu className="w-4.5 h-4.5" />
          </div>
          <span className="font-display font-black text-white text-sm uppercase tracking-wider">
            PRASHANT <span className="text-blue-400 font-mono">JAISWAL</span>
          </span>
        </div>

        {/* CENTER COPYRIGHTS */}
        <div className="text-center font-sans text-xs text-zinc-400 flex items-center gap-1.5 flex-wrap justify-center">
          <span>&copy; {new Date().getFullYear()} Prashant Jaiswal. All rights reserved.</span>
          <span className="hidden sm:inline">|</span>
          <span className="flex items-center gap-1 text-zinc-500">
            Design & Engineering Portfolio
          </span>
        </div>

        {/* RIGHT METRICS LOGS */}
        <div className="font-mono text-[9px] text-zinc-500 uppercase tracking-widest hidden md:block">
          Recruiter Ready
        </div>
      </div>

      {/* FLOAT BACK-TO-TOP CHIP TRIGGER */}
      {showScroll && (
        <button
          onClick={scrollToTop}
          className="fixed bottom-6 right-6 z-40 bg-blue-600 hover:bg-blue-500 text-white rounded-xl p-3 border border-blue-450/20 transition-all duration-300 shadow-[0_4px_20px_rgba(59,130,246,0.3)] hover:-translate-y-1 cursor-pointer flex items-center justify-center"
          aria-label="Scroll back to top of portfolio"
        >
          <ArrowUp className="w-4 h-4 text-white" />
        </button>
      )}
    </footer>
  );
}
