import React from "react";
import { motion } from "motion/react";
import { EXPERIENCE_DATA, TIMELINE_DATA } from "../data";
import { GraduationCap, Briefcase, Calendar, Building, Sparkles, ShieldCheck, Award } from "lucide-react";

export function EducationSection() {
  return (
    <section id="education" className="py-24 px-6 md:px-12 max-w-7xl mx-auto relative z-10">
      {/* SECTION HEADER */}
      <div className="flex flex-col items-center text-center space-y-3 mb-16">
        <div className="inline-flex items-center gap-1.5 bg-blue-950/40 px-3.5 py-1.5 rounded-full border border-blue-500/20 text-blue-400 font-mono text-[10px] uppercase font-bold tracking-wider">
          <GraduationCap className="w-3.5 h-3.5 text-blue-500" />
          Qualifications & Milestones
        </div>
        <h2 className="text-3xl md:text-5xl font-display font-black tracking-tight uppercase text-white">
          EDUCATION & <span className="bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">EXPERIENCE</span>
        </h2>
        <p className="font-sans text-xs md:text-sm text-zinc-400 max-w-2xl leading-relaxed">
          Tracing my academic roadmap in Artificial Intelligence, machine learning models, and real-world software internships.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
        {/* LEFT CARD: ACADEMIC TIMELINE */}
        <div className="border border-white/10 bg-[#11182B]/60 backdrop-blur-xl p-6 md:p-8 rounded-2xl shadow-[0_0_40px_rgba(0,0,0,0.5)] relative">
          <h3 className="font-display font-black text-white uppercase text-base tracking-wider mb-8 text-left flex items-center gap-2">
            <GraduationCap className="w-5 h-5 text-blue-400" />
            <span>Academic Background</span>
          </h3>

          <div className="relative border-l border-white/10 pl-6 md:pl-8 space-y-8 text-left">
            {TIMELINE_DATA.map((item, idx) => {
              const getIcon = () => {
                if (item.type === "education") return <GraduationCap className="w-4 h-4 text-zinc-400 group-hover:text-blue-400" />;
                if (item.type === "certificate") return <ShieldCheck className="w-4 h-4 text-emerald-400 group-hover:text-white" />;
                return <Award className="w-4 h-4 text-amber-400 group-hover:text-white" />;
              };
              return (
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1, duration: 0.4 }}
                  key={item.id}
                  className="relative group"
                >
                  <span className="absolute -left-[35px] md:-left-[43px] top-1.5 w-7 h-7 rounded-full bg-[#0B1020] border border-white/20 flex items-center justify-center text-zinc-400 group-hover:border-blue-500 group-hover:shadow-[0_0_10px_2px_rgba(59,130,246,0.5)] transition-all">
                    {getIcon()}
                  </span>

                  <div className="space-y-1.5">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                      <h4 className="font-display font-bold text-white text-base md:text-lg group-hover:text-blue-400 transition-colors">
                        {item.title}
                      </h4>
                      <span className="font-mono text-[10px] font-bold text-cyan-400 bg-cyan-900/40 px-2 py-0.5 rounded border border-cyan-500/30 inline-block w-fit">
                        {item.year}
                      </span>
                    </div>
                    <p className="font-mono text-[11px] font-bold text-zinc-300 uppercase tracking-widest">
                      {item.institution}
                    </p>
                    <p className="font-sans text-sm text-zinc-300 leading-relaxed">
                      {item.description}
                    </p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* RIGHT CARD: PROFESSIONAL INTERNSHIPS */}
        <div className="border border-white/10 bg-[#11182B]/60 backdrop-blur-xl p-6 md:p-8 rounded-2xl shadow-[0_0_40px_rgba(0,0,0,0.5)] relative">
          <h3 className="font-display font-black text-white uppercase text-base tracking-wider mb-8 text-left flex items-center gap-2">
            <Briefcase className="w-5 h-5 text-indigo-400" />
            <span>Professional Internships</span>
          </h3>

          <div className="relative border-l border-white/10 pl-6 md:pl-8 space-y-8 text-left">
            {EXPERIENCE_DATA.map((exp, idx) => (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1, duration: 0.4 }}
                key={exp.id}
                className="relative group"
              >
                <span className="absolute -left-[35px] md:-left-[43px] top-1.5 w-7 h-7 rounded-full bg-[#0B1020] border border-white/20 flex items-center justify-center text-zinc-400 group-hover:border-indigo-500 group-hover:text-indigo-400 group-hover:shadow-[0_0_10px_2px_rgba(99,102,241,0.5)] transition-all">
                  <Briefcase className="w-4 h-4" />
                </span>

                <div className="space-y-2.5">
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-1">
                    <div>
                      <h4 className="font-display font-bold text-white text-base md:text-lg group-hover:text-indigo-400 transition-colors">
                        {exp.role}
                      </h4>
                      <div className="flex items-center gap-1.5 text-zinc-300 font-mono text-[11px] font-bold mt-0.5">
                        <Building className="w-3.5 h-3.5 text-zinc-400" />
                        <span>{exp.company}</span>
                      </div>
                    </div>
                    <span className="font-mono text-[10px] font-bold text-indigo-400 bg-indigo-900/40 px-2 py-0.5 rounded border border-indigo-500/30 inline-block w-fit shrink-0">
                      {exp.duration}
                    </span>
                  </div>

                  <ul className="space-y-1.5 font-sans text-sm text-zinc-300">
                    {exp.description.map((bullet, bIdx) => (
                      <li key={bIdx} className="flex items-start gap-2 leading-relaxed">
                        <span className="text-indigo-400 shrink-0 select-none mt-0.5 font-bold">▪</span>
                        <span>{bullet}</span>
                      </li>
                    ))}
                  </ul>

                  <div className="flex flex-wrap gap-1.5 pt-3 border-t border-white/10">
                    {exp.techUsed.map((tech) => (
                      <span
                        key={tech}
                        className="bg-white/5 border border-white/10 text-zinc-300 px-2.5 py-0.5 rounded text-[9px] font-mono font-bold uppercase tracking-widest hover:border-indigo-500/40 hover:bg-indigo-500/10 cursor-default transition-colors"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
