import React from "react";
import { motion } from "motion/react";
import { TIMELINE_DATA } from "../data";
import { GraduationCap, Award, BookOpen, User, Star, ArrowDown, ShieldCheck } from "lucide-react";

export function AboutSection() {
  return (
    <section id="about" className="py-24 px-6 md:px-12 max-w-7xl mx-auto relative z-10">
      {/* SECTION HEADER */}
      <div className="flex flex-col items-center text-center space-y-3 mb-16">
        <div className="inline-flex items-center gap-1.5 bg-blue-950/40 px-3.5 py-1.5 rounded-full border border-blue-500/20 text-blue-400 font-mono text-[10px] uppercase font-bold tracking-wider">
          <User className="w-3.5 h-3.5 text-blue-500" />
          Professional Profile
        </div>
        <h2 className="text-3xl md:text-5xl font-display font-black tracking-tight uppercase text-white">
          ABOUT MY <span className="bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">JOURNEY</span>
        </h2>
        <p className="font-sans text-xs md:text-sm text-zinc-400 max-w-2xl leading-relaxed">
          I am a student of BS in Artificial Intelligence & Data Science with cross-functional full-stack software development expertise, dedicated to translating statistical architectures into elegant user experiences.
        </p>
      </div>

      {/* CORE CONTENT LAYOUT: GRID (Left Bio, Right Timeline) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
        
        {/* LEFT COLUMN: PROFESSIONAL PROFILE CARD */}
        <div className="lg:col-span-5 space-y-6">
          <div className="border border-white/10 bg-[#11182B]/60 backdrop-blur-xl p-6 md:p-8 rounded-2xl relative shadow-2xl group overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-blue-500/20 to-transparent rounded-bl-full pointer-events-none" />
            
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-blue-950/50 border border-blue-500/20 flex items-center justify-center">
                  <Star className="w-5 h-5 text-blue-400" />
                </div>
                <div>
                  <h3 className="font-display font-bold text-white text-lg leading-tight uppercase text-left">Prashant Jaiswal</h3>
                  <p className="font-mono text-[10px] text-zinc-400 uppercase tracking-widest text-left">AI & Full-Stack Developer</p>
                </div>
              </div>

              <div className="space-y-3 font-sans text-sm text-zinc-300 leading-relaxed text-left">
                <p>
                  Pursuing a BS in Artificial Intelligence & Data Science, I am building practical experience in statistical machine learning, deep learning architectures, and scalable web backend technologies.
                </p>
                <p>
                  I enjoy developing responsive, user-centric client interfaces backed by powerful server pipelines, ensuring high accessibility, optimal load-speeds, and actionable data visualizations.
                </p>
              </div>

              {/* STATS DECK */}
              <div className="grid grid-cols-3 gap-3 pt-4 border-t border-white/10">
                <div className="text-left bg-white/5 p-3 rounded-lg border border-white/10">
                  <span className="block font-display font-black text-white text-sm md:text-base">BS Degree</span>
                  <span className="block font-mono text-[8px] text-zinc-400 border-white/10 uppercase">ACADEMICS</span>
                </div>
                <div className="text-left bg-white/5 p-3 rounded-lg border border-white/10">
                  <span className="block font-display font-black text-blue-400 text-sm md:text-base">15+</span>
                  <span className="block font-mono text-[8px] text-zinc-400 border-white/10 uppercase">PROJECTS</span>
                </div>
                <div className="text-left bg-white/5 p-3 rounded-lg border border-white/10">
                  <span className="block font-display font-black text-cyan-400 text-sm md:text-base">8+</span>
                  <span className="block font-mono text-[9px] font-bold text-zinc-300 uppercase">ML MODELS</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: TIMELINE LEDGER */}
        <div className="lg:col-span-7 space-y-6">
          <div className="border border-white/10 bg-[#11182B]/60 backdrop-blur-xl p-6 md:p-8 rounded-2xl relative shadow-2xl">
            <h4 className="font-display font-black text-white uppercase text-base tracking-wider mb-8 text-left flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-cyan-400" />
              <span>EDUCATION & ACHIEVEMENTS</span>
            </h4>

            {/* VERTICAL TIMELINE CONTAINER */}
            <div className="relative border-l border-white/10 pl-6 md:pl-8 space-y-8 text-left">
              {TIMELINE_DATA.map((item, idx) => {
                const getIcon = () => {
                  if (item.type === "education") return <GraduationCap className="w-4 h-4" />;
                  if (item.type === "certificate") return <ShieldCheck className="w-4 h-4 text-emerald-400 group-hover:text-emerald-350" />;
                  return <Award className="w-4 h-4 text-amber-400 group-hover:text-amber-300" />;
                };
                return (
                  <motion.div
                    initial={{ opacity: 0, x: 20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: idx * 0.1, duration: 0.4 }}
                    key={item.id}
                    className="relative group"
                  >
                    {/* CUSTOM BULLET MARKER */}
                    <span className="absolute -left-[35px] md:-left-[43px] top-1.5 w-7 text-xs h-7 rounded-full bg-[#0B1020] border border-white/20 flex items-center justify-center text-zinc-200 group-hover:border-blue-500 group-hover:shadow-[0_0_10px_2px_rgba(59,130,246,0.5)] group-hover:bg-blue-900/20 transition-all">
                      {getIcon()}
                    </span>

                    <div className="space-y-1.5">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                        <h5 className="font-display font-bold text-white text-base md:text-lg group-hover:text-blue-400 transition-colors">
                          {item.title}
                        </h5>
                        <span className="font-mono text-[10px] font-bold text-cyan-400 bg-cyan-900/40 px-2 py-0.5 rounded border border-cyan-500/30 inline-block w-fit">
                          {item.year}
                        </span>
                      </div>
                      <p className="font-mono text-[11px] font-bold text-zinc-300 uppercase tracking-widest">
                        {item.institution}
                      </p>
                      <p className="font-sans text-sm text-zinc-300 leading-relaxed">
                        {item.description}
                      </p>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
