import React from "react";
import { motion } from "motion/react";
import { FileText, Download, CheckCircle, Award, Star, Mail, MapPin } from "lucide-react";

export function ResumeSection() {
  const handlePrint = () => {
    window.print();
  };

  const coreStrengths = [
    "Predictive Modelling & Deep Learning (PyTorch, TensorFlow)",
    "Scalable Web Backends (Node.js, Express, SQL/PostgreSQL)",
    "Responsive Frontend Interfaces & Motion (React, Tailwind CSS)",
    "Data Storytelling & Executive Reporting (Power BI, Excel)",
    "Clean Modularity & Strict Branching Workflows (Git, GitHub)"
  ];

  return (
    <section id="resume" className="py-24 px-6 md:px-12 max-w-7xl mx-auto relative z-10">
      {/* SECTION HEADER */}
      <div className="flex flex-col items-center text-center space-y-3 mb-16">
        <div className="inline-flex items-center gap-1.5 bg-blue-950/40 px-3.5 py-1.5 rounded-full border border-blue-500/20 text-blue-400 font-mono text-[10px] uppercase font-bold tracking-wider">
          <FileText className="w-3.5 h-3.5 text-blue-500" />
          Acquisition Corridor
        </div>
        <h2 className="text-3xl md:text-5xl font-display font-black tracking-tight uppercase text-white">
          CURRICULUM <span className="bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">VITAE</span>
        </h2>
        <p className="font-sans text-xs md:text-sm text-zinc-400 max-w-2xl leading-relaxed">
          Acquire a print-ready version of my professional qualifications or view direct capability scorecards.
        </p>
      </div>

      {/* CORE RESUME WORKSPACE */}
      <div className="max-w-4xl mx-auto border border-white/10 bg-[#11182B]/60 backdrop-blur-xl p-6 md:p-10 rounded-2xl shadow-[0_0_40px_rgba(0,0,0,0.5)] space-y-8 text-left relative overflow-hidden">
        
        {/* Subtle decorative glow */}
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-blue-500/10 rounded-full filter blur-3xl pointer-events-none" />

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-white/10">
          <div>
            <h3 className="text-2xl font-display font-black text-white tracking-wide">PRASHANT JAISWAL</h3>
            <p className="font-mono text-xs text-blue-400 uppercase tracking-widest mt-1">AI & DATA SCIENCE student | FULL-STACK DEVELOPER</p>
            <div className="flex flex-wrap gap-4 mt-3 text-sm text-zinc-300">
              <span className="flex items-center gap-1.5 object-cover">
                <MapPin className="w-4 h-4 text-indigo-400" /> State Technological University
              </span>
              <span className="flex items-center gap-1.5">
                <Mail className="w-4 h-4 text-indigo-400" /> prashantjai09@gmail.com
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Download/Print Action Card */}
            <button
              onClick={handlePrint}
              className="cursor-pointer inline-flex items-center gap-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-550 text-white border border-blue-500/20 px-5  py-3 rounded-xl text-xs font-semibold uppercase tracking-wider shadow-[0_0_20px_rgba(59,130,246,0.2)] hover:-translate-y-0.5 transition-all w-full md:w-auto justify-center"
            >
              <Download className="w-4 h-4" />
              <span>Print/Save PDF</span>
            </button>
          </div>
        </div>

        {/* SUMMARY DETAILS */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 pt-2">
          {/* LEFT BIO COLUMN */}
          <div className="md:col-span-7 space-y-6">
            <div className="space-y-3">
              <h4 className="font-display font-bold text-white text-sm uppercase tracking-wider flex items-center gap-2">
                <Star className="w-4 h-4 text-blue-400" />
                <span>Executive Summary</span>
              </h4>
              <p className="font-sans text-xs md:text-sm text-zinc-400 leading-relaxed">
                Pragmatic, detail-oriented engineering student specializing in Artificial Intelligence and Full Stack Javascript frameworks. Experienced in handling machine learning training datasets, configuring responsive user portfolios, and reducing latency bottlenecks for server-side endpoints. Ready to excel in fast-paced software collaborative internship opportunities.
              </p>
            </div>

            <div className="space-y-4">
              <h4 className="font-display font-black text-white text-base md:text-lg uppercase tracking-wider flex items-center gap-2">
                <Award className="w-5 h-5 text-indigo-400" />
                <span>Core Competency Checklist</span>
              </h4>
              <ul className="space-y-3 pt-1">
                {coreStrengths.map((str, idx) => (
                  <li key={idx} className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5 shadow-[0_0_10px_rgba(52,211,153,0.3)] rounded-full bg-[#0B1020]" />
                    <span className="font-sans text-sm md:text-base text-zinc-100 font-medium leading-relaxed">{str}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* RIGHT STAT DETAILS */}
          <div className="md:col-span-5 space-y-6 bg-white/5 p-5 rounded-xl border border-white/10 shadow-[0_0_20px_rgba(0,0,0,0.3)]">
            <h4 className="font-mono text-[10px] text-zinc-400 uppercase tracking-widest font-bold border-b border-white/10 pb-2">Academic Coordinates</h4>
            
            <div className="space-y-4 text-xs md:text-sm font-sans">
              <div>
                <span className="block font-mono text-[10px] text-zinc-400 font-bold uppercase tracking-wider">Candidate Name</span>
                <span className="block font-bold text-white mt-1">Prashant Jaiswal</span>
              </div>
              <div>
                <span className="block font-mono text-[10px] text-zinc-400 font-bold uppercase tracking-wider">Degree Pursued</span>
                <span className="block font-bold text-white mt-1">BS in Artificial Intelligence & Data Science</span>
              </div>
              <div>
                <span className="block font-mono text-[10px] text-zinc-400 font-bold uppercase tracking-wider">Major Topics of Interest</span>
                <span className="block font-medium text-zinc-200 mt-1 leading-relaxed">Statistical Inference, Deep Learning, SQL Server Pipelines, Web Systems</span>
              </div>
              <div className="pt-2">
                <div className="border border-blue-500/10 bg-blue-950/10 p-3 rounded text-[11px] font-mono text-blue-400 flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse" />
                  <span>Actively reviewing Summer 2026 roles</span>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}
