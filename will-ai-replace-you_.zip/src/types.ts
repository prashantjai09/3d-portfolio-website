export interface SkillItem {
  name: string;
  category: "language" | "frontend" | "backend" | "ai-ds" | "tool";
  level: number; // 0-100 percentage
  icon: string; // lucide icon name
  color: string; // tailwind color class
}

export interface ProjectItem {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  longDescription?: string;
  techStack: string[];
  imagePlaceholderUrl?: string;
  githubUrl: string;
  liveUrl: string;
  featured: boolean;
}

export interface ExperienceItem {
  id: string;
  role: string;
  company: string;
  duration: string;
  description: string[];
  techUsed: string[];
}

export interface TimelineItem {
  id: string;
  year: string;
  title: string;
  institution: string;
  description: string;
  type: "education" | "achievement" | "certificate";
}
